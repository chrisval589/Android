package com.chrisvalentine.hwk4bankaccountv2;


import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class fragment_accountlist_activity extends Fragment {

    //Global Variables

    private AccountSelectionCallback callBack;
    BankAccountList ba = BankAccountList.getInstance();
    BankAccount b = new BankAccount();
    ListView accountList;
    ArrayAdapter<String> nameListAdapter;
    ArrayList<String> accountNameList;

    // Define Interface
    public interface AccountSelectionCallback{
        void accountSelected(BankAccount b);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View accountListView = inflater.inflate(R.layout.fragment_accountlist, container, false);

        //Views to inflate
        Button addAccountBtn = (Button) accountListView.findViewById(R.id.add_account_btn);
        accountList = (ListView) accountListView.findViewById(R.id.select_account_list);


        // Initialize List view
        accountNameList = new ArrayList<>();
        nameListAdapter = new ArrayAdapter<>(getContext(), R.layout.listtext, accountNameList);

        accountList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            //ListView handler

            @Override
            public void onItemClick(AdapterView<?> adapter, View v, int position, long arg3) {
                String value = (String) adapter.getItemAtPosition(position);
                //Call name method to match Account with value clicked
                 // and store in bank account variable
                  b = ba.GetAccountByName(value);

                  //start intent and pass account info to account detail fragment
                if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                    Intent detailIntent = new Intent( getContext(), AccountDetailActivity.class);
                    detailIntent.putExtra("aName", b.getAccountName());
                    detailIntent.putExtra("balance", b.getBalance());
                    startActivity(detailIntent);
                }

                    //Use interface to populate detail Fragment if orientation is landscape
                if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    callBack.accountSelected(b);
                }

            }
        });

        // add account handler
        addAccountBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent dataIntent = new Intent(getActivity(), AddAccountActivity.class);
                startActivity(dataIntent);
            }

        });
        return accountListView;
    }


    //Used to
    @Override
    public void onResume() {
        super.onResume();
        // get added account
        BankAccount b;

         nameListAdapter.clear();
         for (int i = 0; i < ba.accountList.size(); i++){
             b = ba.accountList.get(i);
             accountNameList.add(b.getAccountName());
             nameListAdapter.notifyDataSetChanged();
         }
        accountList.setAdapter(nameListAdapter);
    }

    //Used with interface

    @Override
    public void onAttach(Context context){
        super.onAttach(context);
        callBack = (AccountSelectionCallback) context;
    }



}
