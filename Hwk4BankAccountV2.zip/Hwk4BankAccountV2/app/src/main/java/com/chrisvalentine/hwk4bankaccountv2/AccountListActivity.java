package com.chrisvalentine.hwk4bankaccountv2;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;


public class  AccountListActivity extends AppCompatActivity
        implements fragment_accountlist_activity.AccountSelectionCallback{

    // Fragment declarations

   fragment_accountdetail_activity detailFrag = new fragment_accountdetail_activity();
   fragment_accountlist_activity listFrag = new fragment_accountlist_activity();


    //Interface method
    @Override
    public void accountSelected(BankAccount b) {
       detailFrag.ShowAccount(b);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accountlist);

        //Add accountlist fragment to activity

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.accountlist_container, listFrag);
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            ft.add(R.id.account_detail_container, detailFrag);
        }
        ft.commit();
    }




}
