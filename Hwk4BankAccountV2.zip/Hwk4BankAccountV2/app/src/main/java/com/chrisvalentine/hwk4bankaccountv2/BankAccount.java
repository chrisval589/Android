package com.chrisvalentine.hwk4bankaccountv2;



public class BankAccount {

        private String name;
        private double balance;

        public BankAccount(){
            name = "Checking";
            balance = 100.00;
        }

        public BankAccount( String accountName, double accountBalance){
            name = accountName;
            balance = accountBalance;

        }

    public String getAccountName() {
        return name;
    }

    public void setAccountName( String a) {
        name = a;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(Double b) {
        balance = b;
    }

    @Override
    public String toString(){
            return name;
    }
}
