package com.chrisvalentine.hwk4bankaccountv2;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class fragment_app_info_activity extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View appInfoView = inflater.inflate(R.layout.fragment_appinfo, container, false);

        //Views to inflate

        TextView appName = (TextView) appInfoView.findViewById(R.id.appName);
        TextView dev = (TextView) appInfoView.findViewById(R.id.developer);
        TextView version = (TextView) appInfoView.findViewById(R.id.version);


        return appInfoView;
    }
}
