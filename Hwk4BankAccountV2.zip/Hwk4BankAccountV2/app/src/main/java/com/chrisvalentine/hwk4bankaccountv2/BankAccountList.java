package com.chrisvalentine.hwk4bankaccountv2;

import java.util.ArrayList;
import java.util.List;



public final class BankAccountList {

    private static  BankAccountList ourInstance = null;

    List<BankAccount> accountList;
    BankAccount defaultInfo;

    private BankAccountList() {
        accountList = new ArrayList<BankAccount>();
        defaultInfo = new BankAccount("Checking", 100.00);
        accountList.add(defaultInfo);
    }

   public static BankAccountList getInstance() {

        if (ourInstance == null){
            ourInstance = new BankAccountList();
        }
        return ourInstance;
    }

    // Other Methods
    BankAccount GetAccountByName(String name){

        // Intialize
        BankAccount ba;
        BankAccountList bl = BankAccountList.getInstance();

        // Loop through list to find chosen name

        for (int i = 0; i < bl.accountList.size(); i++) {
            ba = bl.accountList.get(i);

            if (name.equals(ba.getAccountName())) {
                return ba;

            }
        }

        return null;

        }



    List<BankAccount> GetInternalList(){
        return accountList;
    }


}
