package com.chrisvalentine.hwk4bankaccountv2;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.EditText;
import android.widget.TextView;



public class fragment_accountdetail_activity extends Fragment {

    //Global variables

    EditText aNameDisplay;
    EditText balance;
    BankAccount ba = new BankAccount();
    BankAccountList bl = BankAccountList.getInstance();





    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View accountDetailView = inflater.inflate(R.layout.fragment_accountdetail, container, false);

        //Views to inflate

        TextView aText = (TextView) accountDetailView.findViewById(R.id.aNameText);
        aNameDisplay =  (EditText) accountDetailView.findViewById(R.id.aNameDisplay);
        TextView balanceView = (TextView) accountDetailView.findViewById(R.id.balanceText);
        balance = (EditText) accountDetailView.findViewById(R.id.balanceDisplay);


        //Default info to display
        aNameDisplay.setText(bl.defaultInfo.getAccountName());
        String defaultBalance = Double.toString(bl.defaultInfo.getBalance());
        balance.setText(defaultBalance);


        //get account info from intent
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            Intent detailIntent = getActivity().getIntent();
            String aName = detailIntent.getStringExtra("aName");
            Double uBalance = detailIntent.getDoubleExtra("balance", 0);

            aNameDisplay.setText(aName);
            String updatedBalance = Double.toString(uBalance);
            balance.setText(updatedBalance);
        }
        return accountDetailView;
    }

    //Interface method

    void ShowAccount(BankAccount b){

        // Initialize
        String aName;
        double uBalance;
        aNameDisplay.setText("");
        balance.setText("");

        // Put values in to new instance

        ba = b;

        // Fill fields
        aName = ba.getAccountName();
        uBalance = ba.getBalance();

        aNameDisplay.setText(aName);
        String defaultBalance = Double.toString(uBalance);
        balance.setText(defaultBalance);

    }

    public void onResume() {
        super.onResume();



    }







}
