package com.chrisvalentine.hwk4bankaccountv2;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class fragment_addaccount_activity extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final EditText aNameValue;
        final EditText balance;

        View addAccountView = inflater.inflate(R.layout.fragment_addaccount, container, false);

        //Views to inflate

        TextView aName = (TextView) addAccountView.findViewById(R.id.aNameView);
        aNameValue = (EditText) addAccountView.findViewById(R.id.aNameInput);
        TextView balanceView = (TextView) addAccountView.findViewById(R.id.balanceView);
        balance = (EditText) addAccountView.findViewById(R.id.balanceInput);
        Button   saveAccount = (Button) addAccountView.findViewById(R.id.saveAccount);



        saveAccount.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                //Initialize variables
                String uName, uBalance;
                Double convertBalance;


                //get userName and balance
                uName = aNameValue.getText().toString();
                uBalance = balance.getText().toString();
                convertBalance = Double.parseDouble(uBalance);

                //Create new BankAccount and add to list
              BankAccountList bl = BankAccountList.getInstance();
              BankAccount ba = new BankAccount( uName, convertBalance);
              bl.accountList.add(ba);
              getActivity().finish();
            }

        });

        return addAccountView;
    }
}
