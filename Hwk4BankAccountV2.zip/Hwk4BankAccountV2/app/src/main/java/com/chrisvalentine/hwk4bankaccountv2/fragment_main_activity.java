package com.chrisvalentine.hwk4bankaccountv2;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class fragment_main_activity extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View fragmentRootView = inflater.inflate(R.layout.fragment_main_activity, container, false);

        //Views to inflate and intents that they use
        // account_display button
        ImageView i = (ImageView) fragmentRootView.findViewById(R.id.display_account);

        i.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent dataIntent = new Intent( getActivity() , AccountListActivity.class);
               startActivity(dataIntent);
            }

        });

        // app info button
        ImageView l = (ImageView) fragmentRootView.findViewById(R.id.app_info);

        l.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent dataIntent = new Intent( getActivity(), AppInfoActivity.class);
                startActivity(dataIntent);
            }

        });

        return fragmentRootView;
    }

}
