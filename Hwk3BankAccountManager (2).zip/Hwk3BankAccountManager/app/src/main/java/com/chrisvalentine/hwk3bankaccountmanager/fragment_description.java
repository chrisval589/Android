package com.chrisvalentine.hwk3bankaccountmanager;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;


public class fragment_description extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View descriptionView = inflater.inflate(R.layout.fragment_description, container, false);

        //Views To inflate
        TextView descriptionText = (TextView) descriptionView.findViewById(R.id.descriptionText);
        EditText description = (EditText) descriptionView.findViewById(R.id.description);

        //Set text of description
        DataActivity data = DataActivity.getInstance();
        description.setText(data.getDescription());

        return descriptionView;

    }
}
