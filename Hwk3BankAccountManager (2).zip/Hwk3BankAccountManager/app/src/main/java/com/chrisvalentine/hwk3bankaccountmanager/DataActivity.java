package com.chrisvalentine.hwk3bankaccountmanager;

public final class DataActivity {
    private static DataActivity ourInstance = null;

    String AccountName;
    double balance;
    String description;

    private DataActivity() {

        AccountName = "Checking";
        balance = 105.55;
        description = "This account is used to pay bills.";


    }

    public static DataActivity getInstance() {

        if(ourInstance == null){
            ourInstance = new DataActivity();
        }




        return ourInstance;
    }

    public String getAccountName() {
        return AccountName;
    }

    public void setAccountName( String a) {
        AccountName = a;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(Double b) {
        balance = b;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription( String d){
       description = d;
    }

}
