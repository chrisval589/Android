package com.chrisvalentine.hwk3bankaccountmanager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class fragment_namebalance extends Fragment {

    //Global Variables

    EditText balance;
    String balanceString = "";
    DataActivity dataClass = DataActivity.getInstance();


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View nameBalanceView = inflater.inflate(R.layout.fragment_namebalance, container, false);

        //Views To inflate
        TextView accountNameView = (TextView) nameBalanceView.findViewById(R.id.accountNameView);
        EditText accountName = (EditText) nameBalanceView.findViewById(R.id.accountName);
        TextView balanceView = (TextView) nameBalanceView.findViewById(R.id.balanceView);
        balance = (EditText) nameBalanceView.findViewById(R.id.balance);
        Button depositBtn = (Button) nameBalanceView.findViewById(R.id.depositBtn);
        Button withdrawBtn = (Button) nameBalanceView.findViewById(R.id.withdrawBtn);

        //Singleton Values

        accountName.setText(dataClass.getAccountName());
        //dataClass.setBalance(dataClass.getBalance());
        balanceString = Double.toString(dataClass.getBalance());
        balance.setText(balanceString);



        // Button handlers

        depositBtn.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    Intent depositIntent = new Intent(fragment_namebalance.this.getContext(), DepositActivity.class);
                    //startActivityForResult(depositIntent, DEPOSIT_REQUEST);
                    startActivity(depositIntent);

                }

            });


            withdrawBtn.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    Intent withdrawIntent = new Intent(fragment_namebalance.this.getContext(), WithdrawActivity.class);
                    //startActivityForResult(withdrawIntent, WITHDRAW_REQUEST);
                    startActivity(withdrawIntent);

                }

            });

            return nameBalanceView;
    }


    //Used to transfer updated balance

    @Override
    public void onResume() {
        super.onResume();

        //Get updated balance
        double updatedBalance = dataClass.getBalance();
        //Convert to string and display in text View
        String updatedBalanceString = Double.toString(updatedBalance);
        balance.setText(updatedBalanceString);
    }







}
