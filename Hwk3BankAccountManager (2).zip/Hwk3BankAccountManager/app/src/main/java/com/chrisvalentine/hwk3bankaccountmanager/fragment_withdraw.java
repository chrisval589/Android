package com.chrisvalentine.hwk3bankaccountmanager;


import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class fragment_withdraw extends Fragment {

    EditText withdrawAmount;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View withdrawView = inflater.inflate(R.layout.fragment_withdraw, container, false);

        //Views to inflate

        TextView withdrawText = (TextView) withdrawView.findViewById(R.id.withdrawString);
        withdrawAmount = (EditText) withdrawView.findViewById(R.id.withdrawAmount);
        Button withdrawButton = (Button) withdrawView.findViewById(R.id.withdrawButton);


        withdrawButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {


                // Withdraw declarations
                double newBalance, amount;
                String wa;
                DataActivity data = DataActivity.getInstance();

                //Withdrawal to balance
                //Convert editText to double
                wa = withdrawAmount.getText().toString();
                amount = Double.parseDouble(wa);

                // subtract to balance and convert back to string
                newBalance = data.getBalance() - amount;
                data.setBalance(newBalance);
                getActivity().finish();
            }

        });

        return withdrawView;
    }

}
