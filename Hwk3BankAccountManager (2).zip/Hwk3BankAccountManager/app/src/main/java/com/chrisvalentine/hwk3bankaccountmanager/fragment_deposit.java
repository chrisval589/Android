package com.chrisvalentine.hwk3bankaccountmanager;



import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;




public class fragment_deposit extends Fragment {

    EditText depositAmount;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View depositView = inflater.inflate(R.layout.fragment_deposit, container, false);

        // Views to inflate

        TextView depositText = (TextView) depositView.findViewById(R.id.depositString);
        depositAmount = (EditText) depositView.findViewById(R.id.depositAmount);
        Button depositButton = (Button) depositView.findViewById(R.id.depositButton);



        // Button handler

        depositButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                // Deposit declarations
                double newBalance, amount;
                String  da, StringBalance;
                DataActivity data = DataActivity.getInstance();

                //deposit to balance
                //Convert editText to double
                da = depositAmount.getText().toString();
                amount = Double.parseDouble(da);

                // add to balance and return to previous activity
                newBalance = data.getBalance() + amount;
                data.setBalance(newBalance);
                getActivity().finish();
            }

        });

        return depositView;


        }

    }






