package com.chrisvalentine.hwk2_messages;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Switch activities

        Button dataBtn = (Button) findViewById(R.id.dataActivityBtn);
        dataBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent dataIntent = new Intent(MainActivity.this, DataActivity.class);
                startActivity(dataIntent);
            }

        });

        // Greeting message

        Button greetingBtn = (Button) findViewById(R.id.greetingBtn);
        greetingBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v){
                Context context = getApplicationContext();
                String greetingString = getResources().getString(R.string.greeting_btn_press);
                CharSequence text = greetingString;
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();


            }
        });

        //goodbye message

        Button goodbyeBtn = (Button) findViewById(R.id.goodbyeBtn);
        goodbyeBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v){
                Context context = getApplicationContext();
                String goodbyeString = getResources().getString(R.string.goodbye_btn_press);
                CharSequence text = goodbyeString;
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });






    }










}
