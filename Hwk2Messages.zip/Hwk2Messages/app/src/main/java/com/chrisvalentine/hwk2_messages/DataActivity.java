package com.chrisvalentine.hwk2_messages;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class DataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        //Copy button

        Button copyBtn = (Button) findViewById(R.id.copyBtn);
        copyBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v){
                EditText userInput = findViewById(R.id.userInput);
                EditText copiedInput = findViewById(R.id.copyInput);
                copiedInput.setText(userInput.getText());

            }
        });

        //Clear Button

        Button clearBtn = (Button) findViewById(R.id.clearBtn);
        clearBtn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v){
                EditText userInput = findViewById(R.id.userInput);
                EditText copiedInput = findViewById(R.id.copyInput);
                userInput.setText("");
                copiedInput.setText("");



            }
        });
    }
}
